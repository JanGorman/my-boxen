# Little Snitch Puppet Module for Boxen

## Usage

```puppet
include littlesnitch
```

## Required Puppet Modules

* `boxen`
