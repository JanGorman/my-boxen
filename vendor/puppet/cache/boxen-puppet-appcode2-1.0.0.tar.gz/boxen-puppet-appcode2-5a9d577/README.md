# AppCode2

## Usage

```puppet
include appcode2
```

## Required Puppet Modules

* `boxen`
* `java`

## Development

Write code. Run `script/cibuild` to test it. Check the `script`
directory for other useful tools.
